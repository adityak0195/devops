$doTest = $args[0]
$doJiraTicket = $args[1]
$hostName = $args[2] 
$taskName = $args[3] 
$githubtoken = $args[4] 

Write-Host '*********************************************************************'
Write-Host 'Do Test:'
Write-Host $doTest
Write-Host 'Do Jira Ticket:'
Write-Host $doJiraTicket
Write-Host 'host Name:'
Write-Host $hostName
Write-Host '*********************************************************************'

if ($doTest -eq 'True') {
	$jiraText = '-'
	Write-Host '*********************************************************************'
	$result = get-content output.json
	$check = 'nok'
	Write-Host $result

	Write-Host '*********************************************************************'

	$checkvalue = '*{"Result":"OK"}*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*skipped because it is already installed*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*is trying to override existing entities*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*is queued for installation on the next server restart*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*"reportMessage": ""*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*"reportMessage":""*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'ok'
	}
	$checkvalue = '*Import Failed:*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'nok-jira'
		$jiraText = 'Extension Import Failed!'
	}
	$checkvalue = '*An error occurred while registering JavaScript resources. Check application log for more details.*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'nok-jira'
		$jiraText = 'An error occurred while registering JavaScript resources. Check application log for more details.'
	}
	$checkvalue = '*Not Acceptable*'
	Write-Host $checkvalue
	Write-Host ($result -like $checkvalue)
	if ($result -like $checkvalue){
		$check = 'nok-jira'
		$jiraText = 'Extension not Accaptable!'
	}

	Write-Host '*********************************************************************'
	Write-Host 'Validation Message'
	$response = $result | ConvertFrom-Json
	Write-Host $response.rows.validate.rows.reportMessage
	Write-Host '*********************************************************************'

	Write-Host $check
	if ($check -eq 'ok'){
		Write-Host "OK Result received"
	} else {
		throw "NOK Result received --> failed"
	}

	Write-Host '*********************************************************************'
} else {
  Write-Host "Skipped!"
}
