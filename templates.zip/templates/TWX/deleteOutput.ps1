param ($doTest)
Write-Host 'Do Delete:'
Write-Host $doTest

if ($doTest -eq 'True') {
	Remove-Item output.json
} else {
  Write-Host "Skipped!"
}
