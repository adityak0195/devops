$pushToTWXhost = $args[0]
$pushToTWXappkey = $args[1]
$pushToTWXfile = $args[2] 

echo "$pushToTWXhost"
echo "$pushToTWXfile"
$env:NO_PROXY=$pushToTWXhost
curl.exe -s -o output.json -X POST -F "file=@$pushToTWXfile" -H "appKey:$pushToTWXappkey" -H "Accept:application/json" -H "X-XSRF-TOKEN:TWX-XSRF-TOKEN-VALUE" -H "Content-Type:multipart/form-data" -k https://$pushToTWXhost/Thingworx/ExtensionPackageUploader
echo "done"

