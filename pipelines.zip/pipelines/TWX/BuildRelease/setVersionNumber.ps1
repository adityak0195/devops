$dir = $args[0]

echo '********************************************************'
echo 'dir:'
echo $dir

echo '********************************************************'
Write-Host 'Current Version:'
$metadata = $dir
$metadata += '/configfiles/metadata.xml'
$metadataContent = get-content $metadata
Write-Host $metadataContent

$metadataxml = New-Object xml
$metadataxml.Load( (Convert-Path $metadata) )

$currentVersion = $metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion
$currentVersions = $currentVersion.Split(".")
Write-Host $currentVersions[0]
Write-Host $currentVersions[1]
Write-Host $currentVersions[2]

Write-Host '*********************************************************************'
Write-Host 'new major version:'
$newMajorVersion = get-date -Format yyyy
$week = get-date -UFormat %V
$week1 = '0' + $week
$week2 = $week1.Substring($week1.Length - 2,2)
$newMajorVersion += $week2
Write-Host $newMajorVersion

Write-Host '*********************************************************************'
Write-Host 'New Version:'

if ([int]$currentVersions[1] -lt [int]$newMajorVersion)
{
	$currentVersions[1] = $newMajorVersion
	$currentVersions[2] = "1"
} else {
	$minorVersion = [int]$currentVersions[2]
	$minorVersion += 1
	$currentVersions[2] = [string]$minorVersion
}

Write-Host $currentVersions[0]
Write-Host $currentVersions[1]
Write-Host $currentVersions[2]
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion = $currentVersions[0]
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion += "."
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion += $currentVersions[1]
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion += "."
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion += $currentVersions[2]
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.vendor = "Knorr-Bremse Services GmbH"
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.minimumThingWorxVersion = "9.3.6"
$metadataxml.Entities.ExtensionPackages.ExtensionPackage.dependsOn = ""

Write-Host $metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion
$metadataxml.Save( (Convert-Path $metadata) )
echo '********************************************************'
get-content $metadata
echo '********************************************************'
$finalResult = $metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion
Write-Output "Final Result"
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=buildVersion]$finalResult"
echo "BUILDVERSION=$finalResult" >> $env:GITHUB_ENV
echo '********************************************************'
