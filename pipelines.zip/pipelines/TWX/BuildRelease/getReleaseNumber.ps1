$dir = $args[0]

echo '********************************************************'
echo 'dir:'
echo $dir

echo '********************************************************'
Write-Host 'Current Version:'
$metadata = $dir
$metadataContent = get-content $metadata
Write-Host $metadataContent

$metadataxml = New-Object xml
$metadataxml.Load( (Convert-Path $metadata) )

echo '********************************************************'
$finalResult = $metadataxml.Release.LastBuild.preReleaseVersion
Write-Host 'Current Pre-releaseVersion: variable PRERELEASEVERSION'
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=preReleaseVersion]$finalResult"
echo "PRERELEASEVERSION=$finalResult" >> $env:GITHUB_ENV
Write-Output "##vso[task.setvariable variable=priviousPreReleaseVersion]$finalResult"
echo "PRIVIOUSPRERELEASEVERSION=$finalResult" >> $env:GITHUB_ENV
echo '********************************************************'
echo '********************************************************'
$finalResult = $metadataxml.Release.LastBuild.releaseVersion
Write-Output "Final Result"
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=releaseVersion]$finalResult"
echo "RELEASEVERSION=$finalResult" >> $env:GITHUB_ENV
echo '********************************************************'
