$dir = $args[0]

echo '********************************************************'
echo 'dir:'
echo $dir

echo '********************************************************'
Write-Host 'Current Version:'
$metadata = $dir
$metadata += '/configfiles/metadata.xml'
$metadataContent = get-content $metadata
Write-Host $metadataContent

$metadataxml = New-Object xml
$metadataxml.Load( (Convert-Path $metadata) )

echo '********************************************************'
$finalResult = $metadataxml.Entities.ExtensionPackages.ExtensionPackage.packageVersion
Write-Output "Final Result"
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=buildVersion]$finalResult"
echo "BUILDVERSION=$finalResult" >> $env:GITHUB_ENV
echo '********************************************************'
