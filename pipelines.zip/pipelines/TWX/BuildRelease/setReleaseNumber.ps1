$dir = $args[0]
$isPreRelease = $args[1]

echo '********************************************************'
echo 'dir:'
echo $dir
echo 'isPreRelease:'
echo $isPreRelease


echo '********************************************************'
$metadata = $dir
$metadataContent = get-content $metadata
$metadataxml = New-Object xml
$metadataxml.Load( (Convert-Path $metadata) )
get-content $metadata

echo '********************************************************'
Write-Host 'Current preReleaseVersion: variable PRIVIOUSPRERELEASEVERSION'
$preReleaseVersion = $metadataxml.Release.LastBuild.preReleaseVersion
Write-Output "##vso[task.setvariable variable=priviousPreReleaseVersion]$preReleaseVersion"
echo "PRIVIOUSPRERELEASEVERSION=$preReleaseVersion" >> $env:GITHUB_ENV
$preReleaseVersions = $preReleaseVersion.Split(".")
Write-Host $preReleaseVersion

echo '********************************************************'
Write-Host 'Current releaseVersion:'
$currentVersion = $metadataxml.Release.LastBuild.releaseVersion
Write-Output "##vso[task.setvariable variable=priviousReleaseVersion]$currentVersion"
echo "PRIVIOUSRELEASEVERSION=$currentVersion" >> $env:GITHUB_ENV
Write-Host $currentVersion
$currentVersions = $currentVersion.Split(".")

Write-Host '*********************************************************************'
Write-Host 'New major version number (Year-Week):'
$newMajorVersion = get-date -Format yyyy
$week = get-date -UFormat %V
$week1 = '0' + $week
$week2 = $week1.Substring($week1.Length - 2,2)
$newMajorVersion += $week2
Write-Host $newMajorVersion

Write-Host '*********************************************************************'
Write-Host 'New releaseVersion:'

if ($isPreRelease -ne 'true')
{
	if ([int]$currentVersions[0] -lt [int]$newMajorVersion)
	{
		$currentVersions[0] = $newMajorVersion
		$currentVersions[1] = "1"
	} else {
		$minorVersion = [int]$currentVersions[1]
		$minorVersion += 1
		$currentVersions[1] = [string]$minorVersion
	}

	$metadataxml.Release.LastBuild.releaseVersion = $currentVersions[0]
	$metadataxml.Release.LastBuild.releaseVersion += "."
	$metadataxml.Release.LastBuild.releaseVersion += $currentVersions[1]
}
Write-Host $metadataxml.Release.LastBuild.releaseVersion

Write-Host '*********************************************************************'
Write-Host 'New preReleaseVersion:'

if ($isPreRelease -eq 'true')
{
	if ($preReleaseVersions.Count -eq 2)
	{
		Write-Host 'Migrate preReleaseVersion'
		$metadataxml.Release.LastBuild.preReleaseVersion = $metadataxml.Release.LastBuild.releaseVersion
		$metadataxml.Release.LastBuild.preReleaseVersion += ".0"
	}
	
	if (($preReleaseVersions[0] -ne $currentVersions[0]) -or ($preReleaseVersions[1] -ne $currentVersions[1]))
	{
		Write-Host 'New Release in between'
		$metadataxml.Release.LastBuild.preReleaseVersion = $metadataxml.Release.LastBuild.releaseVersion
		$metadataxml.Release.LastBuild.preReleaseVersion += ".0"
	}
	
	$preReleaseVersion = $metadataxml.Release.LastBuild.preReleaseVersion
	$preReleaseVersions = $preReleaseVersion.Split(".")
	$preMinorVersion = [int]$preReleaseVersions[2]
	$preMinorVersion += 1
	$preReleaseVersion = $preReleaseVersions[0]
	$preReleaseVersion += "."
	$preReleaseVersion += $preReleaseVersions[1]
	$preReleaseVersion += "."
	$preReleaseVersion += [string]$preMinorVersion
	$metadataxml.Release.LastBuild.preReleaseVersion = $preReleaseVersion
}
Write-Host $metadataxml.Release.LastBuild.preReleaseVersion

echo '********************************************************'
$metadataxml.Save( (Convert-Path $metadata) )
get-content $metadata
echo '********************************************************'
$finalResult = $metadataxml.Release.LastBuild.preReleaseVersion
Write-Host 'Current Pre-releaseVersion: variable PRERELEASEVERSION'
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=preReleaseVersion]$finalResult"
echo "PRERELEASEVERSION=$finalResult" >> $env:GITHUB_ENV
echo '********************************************************'

$finalResult = $metadataxml.Release.LastBuild.releaseVersion
Write-Host 'Current releaseVersion: variable RELEASEVERSION'
Write-Output $finalResult
Write-Output "##vso[task.setvariable variable=releaseVersion]$finalResult"
echo '********************************************************'
