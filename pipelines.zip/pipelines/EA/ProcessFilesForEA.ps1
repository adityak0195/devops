$server = $args[0]
$DB = $args[1]
$User = $args[2]
$PW = $args[3]
$extension = $args[4]
$directoryPath = $args[5]



echo '********************************************************'
echo 'User:'
echo $User
echo 'Server:'
echo $server
echo 'DB:'
echo $DB
echo 'Extension:'
echo $extension
echo 'Directory Path:'
echo $directoryPath



Set-Content -Path .\AllFiles.txt -Value "Files:"
foreach ($item in Get-ChildItem -Path $directoryPath -Recurse -Filter "*.xml") {
    if ($item.PSIsContainer) {
        Write-Host "Verzeichnis: $($item.FullName)"
    } else {
        Write-Host "Datei: $($item.FullName)"
        
        $content = Get-Content $item.FullName -raw
        $content = $content.Replace("'", '"')

        Set-Content -Path SQL.sql -NoNewline -Value "exec DIB3_EA_CreateThingworxObject @extension='"
        Add-Content -Path SQL.sql -NoNewline -Value $extension
        Add-Content -Path SQL.sql -NoNewline -Value "', @xml = '"
        Add-Content -Path SQL.sql -NoNewline -Value $content
        Add-Content -Path SQL.sql -NoNewline -Value "'"
        Add-Content -Path AllFiles.txt -Value $item.FullName

        Write-Host "*******************************************"
        cmd /c "DevOps\pipelines\EA\ProcessFilesForEA.bat $User $PW $server $DB"
        Write-Host "*******************************************"
        
    }
}


